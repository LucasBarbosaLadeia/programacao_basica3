
public class Main {
    public static void main(String[] args) {

        Aluno aluno1 = new Aluno("Lucas de Almeida", 19, 89.5, 1.95);
        Aluno aluno2 = new Aluno("Cezar Junior", 23, 78.0, 1.58);
        Aluno aluno3 = new Aluno("João Vitor", 17, 60.9, 1.73);
        Aluno aluno4 = new Aluno("Julia Fernandes", 20, 58.1, 1.59);


        System.out.println(aluno1);
        System.out.println();
        System.out.println(aluno2);
        System.out.println();
        System.out.println(aluno3);
        System.out.println();
        System.out.println(aluno4);
    }
}