public class Universidade {
    public String nome;

    public Universidade(String nome) {
        this.nome = nome;
    }
    public String getNome(){
        return nome;
    }
}
